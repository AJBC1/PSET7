<h3><?= $stock["symbol"] ?></h3>
<h2><?= $stock["name"] ?></h2>
Price: $<?= $stock["price"] ?>   

