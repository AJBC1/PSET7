<form action="prechange.php" method="post">
    <fieldset>
        <div class="form-group">
            <input class="form-control" name="oldpass" placeholder="Insert Old Password" type="password"/>
        </div>
        
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Continue
            </button>
        </div>
    </fieldset>
</form>