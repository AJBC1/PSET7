<html>
    <body>
        <center>
        <h3>Password was changed succesfully!</h3>
        </center>
    </body>
</html>    